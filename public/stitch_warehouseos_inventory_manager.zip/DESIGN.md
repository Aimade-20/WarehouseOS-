---
name: Industrial Precision System
colors:
  surface: '#f9f9ff'
  surface-dim: '#cfdaf2'
  surface-bright: '#f9f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f0f3ff'
  surface-container: '#e7eeff'
  surface-container-high: '#dee8ff'
  surface-container-highest: '#d8e3fb'
  on-surface: '#111c2d'
  on-surface-variant: '#594139'
  inverse-surface: '#263143'
  inverse-on-surface: '#ecf1ff'
  outline: '#8d7167'
  outline-variant: '#e1bfb4'
  surface-tint: '#a83900'
  primary: '#a43700'
  on-primary: '#ffffff'
  primary-container: '#cb4a0a'
  on-primary-container: '#fffbff'
  inverse-primary: '#ffb59a'
  secondary: '#525e7a'
  on-secondary: '#ffffff'
  secondary-container: '#d3dfff'
  on-secondary-container: '#56637e'
  tertiary: '#4d5d73'
  on-tertiary: '#ffffff'
  tertiary-container: '#66768d'
  on-tertiary-container: '#fdfcff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdbcf'
  primary-fixed-dim: '#ffb59a'
  on-primary-fixed: '#380d00'
  on-primary-fixed-variant: '#802a00'
  secondary-fixed: '#d8e2ff'
  secondary-fixed-dim: '#bac6e6'
  on-secondary-fixed: '#0e1b33'
  on-secondary-fixed-variant: '#3a4761'
  tertiary-fixed: '#d3e4fe'
  tertiary-fixed-dim: '#b7c8e1'
  on-tertiary-fixed: '#0b1c30'
  on-tertiary-fixed-variant: '#38485d'
  background: '#f9f9ff'
  on-background: '#111c2d'
  surface-variant: '#d8e3fb'
typography:
  headline-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
  data-mono:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  gutter: 16px
  margin-mobile: 16px
  margin-desktop: 32px
---

## Brand & Style

This design system is engineered for high-stakes industrial environments where speed, accuracy, and clarity are paramount. The brand personality is **authoritative, resilient, and highly technical**, yet maintains the approachability of a modern SaaS platform. It aims to evoke a sense of controlled efficiency and "industrial-grade" reliability.

The design style is **Modern Corporate with a Technical Edge**. It prioritizes high data density and functional utility without sacrificing aesthetic polish. It utilizes a structured grid, crisp borders, and a purposeful use of vibrant "safety" colors to draw attention to critical actions and system statuses, reflecting the physical environment of a warehouse (signage, machinery, and safety markings).

## Colors

The palette is anchored by **Deep Navy (#101D35)** and **Slate Gray (#64748B)** to provide a professional, stable foundation. These colors are used for navigation, structural elements, and primary text to ensure high legibility and reduced eye strain during long shifts.

**Safety Orange (#F06428)** serves as the primary action color. This high-visibility hue is reserved for critical CTA buttons, primary interactions, and active states, mimicking industrial safety standards. 

Functional colors are critical for this design system:
- **Success:** Forest Green (#10B981) for "In Stock" or "Completed."
- **Warning:** Amber (#F59E0B) for "Low Stock" or "Pending."
- **Critical:** Crimson (#EF4444) for "Out of Stock" or "System Error."
- **Background:** A very light cool gray (#F8FAFC) is used to maintain a clean, modern workspace.

## Typography

This design system utilizes **Inter** as its primary typeface due to its exceptional legibility in data-heavy interfaces. It features a tall x-height and distinct letterforms, which are vital for reading SKU numbers and inventory counts quickly.

A secondary font, **JetBrains Mono**, is introduced specifically for "data-mono" roles. Use this for SKU numbers, tracking IDs, and barcodes to ensure characters like '0' and 'O' or '1' and 'l' are never confused. 

Typography should follow a strict hierarchy: 
- Use **Bold** or **SemiBold** weights for headlines and labels to create immediate visual anchors. 
- Use **Medium** for interactive elements and data points.
- Use **Regular** only for descriptive body text to maintain high contrast against the background.

## Layout & Spacing

The layout utilizes a **12-column fluid grid** for desktop and a **single-column fluid layout** for mobile handheld devices (often used for scanning). A 4px baseline grid ensures vertical rhythm across all components.

**Key Layout Principles:**
- **Density:** High density is preferred. Use 12px or 16px padding for containers to maximize the information visible on-screen at once.
- **Data Tables:** These are the heart of the system. Tables should use a fixed header and horizontal scrolling for wide datasets. Row heights should be kept compact (40px-48px).
- **Responsive Reflow:** On mobile, complex tables should transform into "card-list" views where each row becomes a standalone card containing the most critical data points (SKU, Quantity, Status).

## Elevation & Depth

To maintain a "technical" and "robust" feel, this design system avoids heavy, soft shadows. Instead, it uses **Tonal Layering** and **Subtle Outlines** to define hierarchy.

- **Level 0 (Surface):** The main application background (#F8FAFC).
- **Level 1 (Card/Container):** Pure white background with a 1px solid border (#E2E8F0). No shadow.
- **Level 2 (Dropdowns/Modals):** Pure white background with a crisp, low-blur shadow (0px 4px 12px rgba(16, 29, 53, 0.1)) to indicate temporary overlay.
- **Interactive States:** Hovering over a clickable row or card should change the background to a subtle blue tint (#F1F5F9) rather than lifting it via shadow.

## Shapes

The shape language is **Soft (0.25rem)**. This provides a modern feel while maintaining the structured, architectural integrity expected of industrial software. 

- **Small Components:** Checkboxes, buttons, and input fields use a `0.25rem` (4px) radius.
- **Large Components:** Cards and modals use a `0.5rem` (8px) radius.
- **Status Badges:** Use a "pill" shape (full rounding) to clearly differentiate status indicators from buttons or input fields.

## Components

### Buttons
- **Primary:** Safety Orange background, White text. Bold weight. Used for "Confirm Shipment," "Save Changes," or "Finalize Audit."
- **Secondary:** Deep Navy background, White text. For navigation or secondary actions.
- **Ghost:** Transparent background, Slate Gray border and text. Used for "Cancel" or "Go Back."

### Status Badges
- High-contrast background with dark text. 
- **In Stock:** Light Green background / Dark Green text.
- **Low Stock:** Light Amber background / Dark Brown text.
- **Out of Stock:** Light Red background / Dark Red text.

### Data Tables
- Headers must be Slate Gray (#64748B) with all-caps label-md typography.
- Alternating row stripes (zebra striping) using a very faint gray (#F1F5F9) to assist horizontal eye tracking across wide rows.
- Use the **data-mono** font for all SKU and numeric columns.

### Inputs & Forms
- Inputs feature a 1px Slate Gray border that turns Safety Orange on focus. 
- Error states must include both a red border and a small icon for accessibility in high-glare environments.

### Inventory Cards
- For mobile views, cards should feature the SKU in the top-left (bold), the current count in the top-right (large, primary color), and a clear "Scan" button at the bottom.